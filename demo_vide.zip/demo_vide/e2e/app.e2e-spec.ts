import { DemoVidePage } from './app.po';

describe('demo-vide App', function() {
  let page: DemoVidePage;

  beforeEach(() => {
    page = new DemoVidePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});

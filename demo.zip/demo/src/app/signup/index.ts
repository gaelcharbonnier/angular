/**
*  This barrel file provides the export for the lazy loaded SignupComponent.
*/
export * from './signup.component';
export * from './signup.routes';

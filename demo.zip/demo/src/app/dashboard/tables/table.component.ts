import {Component} from '@angular/core';

@Component({
  selector: 'tables-cmp',
  templateUrl: 'tables.component.html'
})

export class TableComponent {}

import { Component } from '@angular/core';

@Component({
    selector: 'bs-element',
    templateUrl: './bs-element.component.html'
})

export class BSElementComponent {}

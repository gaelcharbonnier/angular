import { Component } from '@angular/core';

@Component({
    selector: 'blank-page',
    templateUrl: './blank-page.component.html'
})

export class BlankPageComponent {}

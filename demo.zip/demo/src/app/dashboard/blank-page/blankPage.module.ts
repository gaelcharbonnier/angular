import { NgModule } from '@angular/core';

import { BlankPageComponent } from './blankPage.component';

@NgModule({
    imports: [],
    declarations: [BlankPageComponent],
    exports: [BlankPageComponent]
})

export class BlankPageModule { }

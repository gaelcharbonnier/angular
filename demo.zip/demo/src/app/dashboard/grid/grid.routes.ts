import { Route } from '@angular/router';

import { GridComponent } from './index';

export const GridRoutes: Route[] = [
  {
    path: 'grid',
    component: GridComponent
  },
];

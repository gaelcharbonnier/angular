import {Component} from '@angular/core';

@Component({
    selector: 'form-cmp',
    templateUrl: './forms.component.html'
})

export class FormComponent {}
